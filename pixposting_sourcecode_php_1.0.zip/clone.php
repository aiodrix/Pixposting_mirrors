﻿<?php
session_start();

// Dummy user for session example
$_SESSION['user'] = 'User';

// Function to get the file size in bytes from the URL
function getFileSize($url) {
    $headers = get_headers($url, 1);
    return isset($headers['Content-Length']) ? $headers['Content-Length'] : 0;
}

// Function to download the file if it doesn't exceed the size limit
function downloadFile($url, $filePath) {
    $fileSize = getFileSize($url);
    if ($fileSize > 5242880) { // 5MB in bytes
        die("File size exceeds 5MB. Download aborted.");
    }

    $fileData = file_get_contents($url);
    if ($fileData === FALSE) {
        die("Failed to download the file.");
    }

    file_put_contents($filePath, $fileData);
    return $filePath;
}

// Function to check if the hash of a URL exists in the 'hashes' directory
function checkHash($url) {
    $tempFilePath = sys_get_temp_dir() . '/temp_download';
    downloadFile($url, $tempFilePath);

    // Compute the SHA-1 hash of the downloaded file
    $fileHash = sha1_file($tempFilePath);
    unlink($tempFilePath); // Delete the temporary file

    // Check if the hash exists in the 'hashes' directory
    $hashDirectory = __DIR__ . '/hashes/';
    $hashFilePath = $hashDirectory . $fileHash;

    return file_exists($hashFilePath) ? $fileHash : false;
}

// Ensure the servers directory exists
$serversDir = __DIR__ . '/servers/';
if (!is_dir($serversDir)) {
    mkdir($serversDir, 0755, true);
}

// Determine the servers file path based on the current date
$serversFilePath = $serversDir . 'servers_' . date('Y-m-d') . '.txt';

if (isset($_POST['url'])) {
    $url = $_POST['url'];
    
    // Ensure the URL is valid
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        die("Invalid URL.");
    }

    // Download the file to a temporary location and check its hash
    $fileHash = checkHash($url);

    if ($fileHash) {
        echo "File with hash $fileHash already exists.<br>";

        // Write the URL, user, date, and hash to the servers.txt file
        $user = isset($_SESSION['user']) ? $_SESSION['user'] : 'Anonymous';
        $date = date('Y-m-d H:i:s');
        $entry = "$url\t$user\t$date\t$fileHash\n";

        $file = fopen($serversFilePath, 'a');
        fwrite($file, $entry);
        fclose($file);
    } else {
        echo "The file hash does not exist in the 'hashes' directory. Entry will not be written.<br>";
    }
}

// Handle URL clicks from the table
if (isset($_GET['check_url'])) {
    $checkUrl = $_GET['check_url'];

    // Ensure the URL is valid
    if (!filter_var($checkUrl, FILTER_VALIDATE_URL)) {
        die("Invalid URL.");
    }

    // Check if the hash of the URL exists in the 'hashes' directory
    if (!checkHash($checkUrl)) {
        // Remove the entry from servers.txt if the hash does not exist
        $entries = file($serversFilePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $entries = array_filter($entries, function($line) use ($checkUrl) {
            return strpos($line, $checkUrl) === false;
        });

        $file = fopen($serversFilePath, 'w');
        fwrite($file, implode("\n", $entries) . "\n");
        fclose($file);
        echo "The page has changed. The entry has been removed.<br>";
    } else {
        echo "<a href=\"$checkUrl\" target=\"_blank\">The page is unchanged. Click here to open it in a new tab.</a>";
        echo "<script>window.location.href='$checkUrl';</script>";
    }
}

// Display the content of servers.txt in a table
if (file_exists($serversFilePath)) {
    echo "<h3>Content of servers:</h3>";
    echo '<table class="servers-content">';
    echo '<tr><th>URL</th><th>User</th><th>Date</th><th>Hash</th></tr>';
    $entries = file($serversFilePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($entries as $line) {
        list($url, $user, $date, $hash) = explode("\t", trim($line));
        echo "<tr><td><a href=\"?check_url=" . urlencode($url) . "\">$url</a></td><td>$user</td><td>$date</td><td>$hash</td></tr>";
    }
    echo '</table>';
} else {
    echo "<h3>No entries in servers.txt.</h3>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>File Download and Hash Check</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            display: inline-block;
            width: 100px;
        }
        .servers-content {
            border-collapse: collapse;
            width: 100%;
            text-align: center;
        }
        .servers-content th, .servers-content td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        .servers-content th {
            background-color: #f2f2f2;
        }
        .servers-content td a {
            color: #007bff;
            text-decoration: none;
        }
        .servers-content td a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form method="post" action="">
        <label for="url">Enter URL:</label>
        <input type="text" id="url" name="url" required>
        <button type="submit">Submit</button>
    </form>

<div style="
    background: linear-gradient(to bottom, #e0e0e0, #c0c0c0);
    border-radius: 10px;
    padding: 20px;
    font-family: Arial, sans-serif;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
">
    <p>Você pode hospedar uma página em outro local, e compartilhar o link aqui. O link da página será removido se ela sofrer alterações externas.</p>
    <p><i>You can  host a page elsewhere, and share the link here. The page link will be removed if any changes are detected.</i></p>    
</div>

</body>
</html>
