<?php
// Get the user's IP address
$user_ip = $_SERVER['REMOTE_ADDR'];

// Generate the SHA1 hash of the IP address
$hash_ip = sha1($user_ip);

// Define the directory with the current date
$date_folder = date('d/m/Y');
$directory = 'ip_hash/' . $date_folder;
$file_path = $directory . '/' . $hash_ip;

// Replace slashes in the date format with underscores to avoid directory creation issues
$date_folder_sanitized = str_replace('/', '_', $date_folder);
$directory = 'ip_hash/' . $date_folder_sanitized;
$file_path = $directory . '/' . $hash_ip;

// Check if the directory exists, if not, create it
if (!is_dir($directory)) {
    mkdir($directory, 0755, true);
}

// Check if the file exists
if (file_exists($file_path)) {
    // If the file exists, show the modal JS form
    echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            var modal = document.createElement("div");
            modal.style.position = "fixed";
            modal.style.top = "0";
            modal.style.left = "0";
            modal.style.width = "100%";
            modal.style.height = "100%";
            modal.style.backgroundColor = "rgba(0, 0, 0, 0.5)";
            modal.style.display = "flex";
            modal.style.justifyContent = "center";
            modal.style.alignItems = "center";
            modal.style.fontFamily = "Arial, sans-serif";

            var form = document.createElement("div");
            form.style.backgroundColor = "#fff";
            form.style.padding = "20px";
            form.style.borderRadius = "5px";
            form.style.textAlign = "center";
            form.innerHTML = "<h2>You need to buy an account</h2><button onclick=\'closeModal()\'>Close</button>";

            modal.appendChild(form);
            document.body.appendChild(modal);

            window.closeModal = function() {
                window.location.href = "index.php";
            };
        });
    </script>';
} else {
    // If the file does not exist, create it using fopen
    $file_handle = fopen($file_path, 'w');
    if ($file_handle) {
        fclose($file_handle);
    }

    echo '<p>Welcome! Your access is granted.</p>';
}
?>