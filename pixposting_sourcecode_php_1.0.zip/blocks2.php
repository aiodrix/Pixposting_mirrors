<?php

class Block {
    public $key;
    public $contents;
    public $previousHash;
    public $hash;

    public function __construct($key, $contents, $previousHash = '') {
        $this->key = $key;
        $this->contents = $contents;
        $this->previousHash = $previousHash;
        $this->hash = $this->calculateHash();
    }

    public function calculateHash() {
        return hash('sha256', $this->key . $this->contents . $this->previousHash);
    }
}

class Blockchain {
    private $chain = [];
    private $blocksDir = 'blocks';

    public function __construct() {
        // Create the 'blocks' directory if it doesn't exist
        if (!is_dir($this->blocksDir)) {
            mkdir($this->blocksDir, 0755, true);
        }
        $this->addBlock(0, 'Genesis Block');
    }

    public function addBlock($key, $contents) {
        $previousBlock = end($this->chain);
        $previousHash = $previousBlock ? $previousBlock->hash : '';
        $newBlock = new Block($key, $contents, $previousHash);
        $this->chain[] = $newBlock;
        $this->saveBlockToFile($newBlock);
    }

    private function saveBlockToFile($block) {
        $filename = $this->blocksDir . '/block_' . $block->key . '.txt';
        $data = [
            'key' => $block->key,
            'contents' => $block->contents,
            'previousHash' => $block->previousHash,
            'hash' => $block->hash
        ];
        file_put_contents($filename, json_encode($data));
    }
}

$blockchain = new Blockchain();
$blockchain->addBlock(1, 'Block 1 contents');
$blockchain->addBlock(2, 'Block 2 contents');
$blockchain->addBlock(3, 'Block 3 contents');

?>