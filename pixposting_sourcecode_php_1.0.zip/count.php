<?php
// Define the directory path
$usersDir = 'users';

// Check if the directory exists
if (is_dir($usersDir)) {
    // Initialize an array to hold folder names and their file counts
    $folders = [];

    // Open the users directory
    if ($handle = opendir($usersDir)) {
        // Loop through each folder in the users directory
        while (false !== ($entry = readdir($handle))) {
            // Skip the current and parent directory entries
            if ($entry != '.' && $entry != '..' && is_dir("$usersDir/$entry")) {
                // Count the files in the current folder
                $fileCount = count(glob("$usersDir/$entry/*"));
                // Store the folder name and file count in the array
                $folders[$entry] = $fileCount;
            }
        }
        // Close the directory handle
        closedir($handle);
    }

    // Sort the folders array in descending order by file count
    arsort($folders);

    // Display the results
    echo "<h1>Top '$usersDir'</h1>";
    echo "<ul>";
    foreach ($folders as $folder => $count) {
        echo "<li><strong>$folder</strong>: $count clicks</li>";
    }
    echo "</ul>";
} else {
    echo "Directory '$usersDir' does not exist.";
}
?>
