Voc� est� utilizando a vers�o b�sica do nosso projeto que permite compartilhar, editar, usar com fins comerciais ou n�o
, desde que, mantenha nossos cr�ditos. Voc� pode comprar o c�digo-fonte completo da nossa aplica��o entrando em contato 
conosco, assim como outros servi�os de freelancer remoto.
-----------------------------------------------------------------------------------------------------------------------

You are using the basic version of our project which allows sharing, editing, and commercial or non-commercial use,
provided that you keep our credits. You can purchase the full source code of our application by contacting us, as well
as gain access to other remote web freelancer services.

License : MIT


Contact

E-mail  : 2nodesw@gmail.com
Twitter : https://x.com/2_nodes
Twitter : https://x.com/pixposting
Telegram: https://t.me/aio2nodes


2_nodes - all rights reserved