<?php
if (isset($_GET['json'])) {
    $json = $_GET['json'];

    // Decode the JSON data
    $data = json_decode($json, true);

    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        die('Invalid JSON data.');
    }

    // Get the category field
    if (!isset($data['category'])) {
        die('Category field is missing.');
    }

    $category = $data['category'];

    // Create the folder if it doesn't exist
    if (!file_exists($category)) {
        mkdir($category, 0777, true);
    }

    // Convert the JSON data back to string for hashing and saving
    $jsonDataString = json_encode($data);

    // Generate SHA-256 hash of the JSON data
    $hash = hash('sha256', $jsonDataString);

    // Define the file path
    $filePath = $category . DIRECTORY_SEPARATOR . $hash . '.json';

    // Save the JSON data to the file
    file_put_contents($filePath, $jsonDataString);

    echo "Data saved successfully in $filePath";
} else {
    echo 'No JSON data provided.';
}

?>