<?php

function proofOfWork($url, $difficulty = 4)
{
    $hashPrefix = str_repeat('0', $difficulty);
    $contents = file_get_contents($url); // Fetch contents of the URL
    $nonce = 0;

    do {
        $nonce++;
        $hash = hash('sha256', $contents . $nonce);    // Calculate SHA-256 hash with nonce
    } while (substr($hash, 0, $difficulty) !== $hashPrefix);

    return [
        'nonce' => $nonce,
        'hash' => $hash,
    ];
}

// Example usage
$url = 'https://example.com/data';  // Replace with your URL
$difficulty = 4;                    // Adjust difficulty level as needed

$result = proofOfWork($url, $difficulty);
echo "Proof of Work completed:\n";
echo "Nonce: " . $result['nonce'] . "\n";
echo "SHA-256 Hash: " . $result['hash'] . "\n";

?>
