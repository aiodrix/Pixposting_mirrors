<?php
function resizeImage($file, $newWidth) {
    list($width, $height) = getimagesize($file);
    $newHeight = ($height / $width) * $newWidth;
    
    $src = imagecreatefromjpeg($file);
    $dst = imagecreatetruecolor($newWidth, $newHeight);

    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    
    return $dst;
}

function cropImage($image, $cropHeight) {
    $width = imagesx($image);
    $height = imagesy($image);

    $cropY = ($height - $cropHeight) / 2;
    $dst = imagecreatetruecolor($width, $cropHeight);

    imagecopy($dst, $image, 0, 0, 0, $cropY, $width, $cropHeight);
    
    return $dst;
}

function saveImage($image, $file) {
    imagejpeg($image, $file);
    imagedestroy($image);
}

// Main script
$file = 'test.jpg'; // Path to your image
$newWidth = 300;
$cropHeight = 200;
$outputFile = 'resized_and_cropped_image.jpg'; // Path to save the new image

$resizedImage = resizeImage($file, $newWidth);
$croppedImage = cropImage($resizedImage, $cropHeight);
saveImage($croppedImage, $outputFile);

echo "Image resized and cropped successfully.";
?>
