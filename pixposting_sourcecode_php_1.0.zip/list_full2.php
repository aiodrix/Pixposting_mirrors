<?php
$hashesFolder = 'hashes';

// Check if 'hashes' folder exists
if (is_dir($hashesFolder)) {
    // Get list of folders
    $folders = scandir($hashesFolder);
    $folderCounts = [];

    // Iterate through each folder inside 'hashes' and count files
    foreach ($folders as $folder) {
        if ($folder != '.' && $folder != '..' && is_dir($hashesFolder . '/' . $folder)) {
            // List files inside the folder
            $files = scandir($hashesFolder . '/' . $folder);
            $fileCount = count($files) - 2; // Subtracting '.' and '..'

            // Store folder name and file count in array
            $folderCounts[$folder] = $fileCount;
        }
    }

    // Sort folders based on file count in descending order
    arsort($folderCounts);

    // Output the sorted folders and file counts
    echo "<h2>Folders in 'hashes' and File Counts (Descending Order):</h2>";
    echo "<ul>";
    foreach ($folderCounts as $folder => $count) {
        echo "<li>$folder: $count files</li>";
    }
    echo "</ul>";

    // Output all folders in order (original order before sorting)
    echo "<h2>All Folders in 'hashes' (Descending Order by File Count):</h2>";
    echo "<ul>";
    foreach ($folderCounts as $folder => $count) {
        // List files inside the folder again for original order display
        $files = scandir($hashesFolder . '/' . $folder);
        $fileCount = count($files) - 2; // Subtracting '.' and '..'
        
        // Output folder name and file count
        echo "<li>$folder: $fileCount files</li>";
    }
    echo "</ul>";

} else {
    echo "The 'hashes' folder does not exist.";
}
?>