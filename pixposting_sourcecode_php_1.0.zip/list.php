<?php
$hashesFolder = 'hashes';

// Check if 'hashes' folder exists
if (is_dir($hashesFolder)) {
    $folders = scandir($hashesFolder);
    $folderCounts = [];

    // Iterate through each folder inside 'hashes'
    foreach ($folders as $folder) {
        if ($folder != '.' && $folder != '..' && is_dir($hashesFolder . '/' . $folder)) {
            // List files inside the folder
            $files = scandir($hashesFolder . '/' . $folder);
            $fileCount = count($files) - 2; // Subtracting '.' and '..'

            // Store folder name and file count in array
            $folderCounts[$folder] = $fileCount;
        }
    }

    // Sort folders based on file count in descending order
    arsort($folderCounts);

    // Output the folders and file counts
    echo "<h2>Folders in 'hashes' and File Counts:</h2>";
    echo "<ul>";
    foreach ($folderCounts as $folder => $count) {
        echo "<li>$folder: $count files</li>";
    }
    echo "</ul>";

    // Get the folder with the most files
    $mostFilesFolder = key($folderCounts);
    $mostFilesCount = reset($folderCounts);

    echo "<h3>Folder with the most files:</h3>";
    echo "<p>$mostFilesFolder: $mostFilesCount files</p>";
} else {
    echo "The 'hashes' folder does not exist.";
}
?>
