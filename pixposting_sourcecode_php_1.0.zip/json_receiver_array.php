<?php
if (isset($_GET['json'])) {
    $json = $_GET['json'];

    // Decode the JSON data
    $data = json_decode($json, true);

    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        die('Invalid JSON data.');
    }

    // Ensure the data is an array
    if (!is_array($data)) {
        die('JSON data must be an array.');
    }

    foreach ($data as $item) {
        // Get the category field
        if (!isset($item['category'])) {
            die('Category field is missing in one of the items.');
        }

        $category = $item['category'];

        // Create the folder if it doesn't exist
        if (!file_exists($category)) {
            mkdir($category, 0777, true);
        }

        // Convert the item data back to string for hashing and saving
        $itemDataString = json_encode($item);

        // Generate SHA-256 hash of the item data
        $hash = hash('sha256', $itemDataString);

        // Define the file path
        $filePath = $category . DIRECTORY_SEPARATOR . $hash . '.json';

        // Save the item data to the file
        file_put_contents($filePath, $itemDataString);

        echo "Data saved successfully in $filePath<br>";
    }
} else {
    echo 'No JSON data provided.';
}