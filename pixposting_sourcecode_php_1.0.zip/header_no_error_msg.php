<?php error_reporting(0); reporting
ini_set('display_errors', '0');  ?>

