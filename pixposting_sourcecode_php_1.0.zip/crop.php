<?php
function resizeImage($file, $newWidth) {
    list($width, $height) = getimagesize($file);
    $newHeight = ($height / $width) * $newWidth;
    
    $src = imagecreatefromjpeg($file);
    $dst = imagecreatetruecolor($newWidth, $newHeight);

    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    
    return $dst;
}

function cropImage($image, $cropHeight) {
    $width = imagesx($image);
    $height = imagesy($image);

    $cropY = ($height - $cropHeight) / 2;
    $dst = imagecreatetruecolor($width, $cropHeight);

    imagecopy($dst, $image, 0, 0, 0, $cropY, $width, $cropHeight);
    
    return $dst;
}

function saveImage($image, $file) {
    imagejpeg($image, $file);
    imagedestroy($image);
}

// Main script
if (isset($_GET['url'])) {
    $fileUrl = $_GET['url'];
    $newWidth = 225;
    $cropHeight = 150;

    // Download the image from the URL
    $fileContent = file_get_contents($fileUrl);
    
    // Generate SHA-256 hash of the file contents
    $hash = hash('sha256', $fileContent);
    $thumbsDir = 'thumbs';
    $outputFile = $thumbsDir . '/' . $hash . '.jpg';

    // Create 'thumbs' directory if it doesn't exist
    if (!is_dir($thumbsDir)) {
        mkdir($thumbsDir, 0777, true);
    }

    // Save the file content to a temporary file
    $tempFile = tempnam(sys_get_temp_dir(), 'image');
    file_put_contents($tempFile, $fileContent);

    $resizedImage = resizeImage($tempFile, $newWidth);
    $croppedImage = cropImage($resizedImage, $cropHeight);
    saveImage($croppedImage, $outputFile);

    // Clean up temporary file
    unlink($tempFile);

    echo "Image resized and cropped successfully. Saved as: " . $outputFile;
} else {
    echo "Please provide an image URL.";
}
?>
