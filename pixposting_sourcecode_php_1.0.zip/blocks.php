<?php

class Block
{
    public $key;
    public $contents;
    public $previousHash;
    public $hash;

    public function __construct($key, $contents, $previousHash = '')
    {
        $this->key = $key;
        $this->contents = $contents;
        $this->previousHash = $previousHash;
        $this->hash = $this->calculateHash();
    }

    public function calculateHash()
    {
        return hash('sha256', $this->key . $this->contents . $this->previousHash);
    }
}

class Blockchain
{
    private $chain;

    public function __construct()
    {
        $this->chain = [$this->createGenesisBlock()];
        // Ensure the "blocks" directory exists
        if (!file_exists('blocks')) {
            mkdir('blocks', 0777, true); // Create the directory if it doesn't exist
        }
    }

    private function createGenesisBlock()
    {
        return new Block(0, "Genesis Block", "0");
    }

    public function getLatestBlock()
    {
        return end($this->chain);
    }

    public function addBlock($newBlock)
    {
        $newBlock->previousHash = $this->getLatestBlock()->hash;
        $newBlock->hash = $newBlock->calculateHash();
        $this->chain[] = $newBlock;
        $this->saveBlockToFile($newBlock);
    }

    private function saveBlockToFile($block)
    {
        $filename = 'blocks/block_' . $block->key . '.txt'; // Save inside "blocks" directory
        $contents = json_encode([
            'key' => $block->key,
            'contents' => $block->contents,
            'previousHash' => $block->previousHash,
            'hash' => $block->hash
        ], JSON_PRETTY_PRINT);
        file_put_contents($filename, $contents);
    }

    public function isValid()
    {
        for ($i = 1; $i < count($this->chain); $i++) {
            $currentBlock = $this->chain[$i];
            $previousBlock = $this->chain[$i - 1];

            if ($currentBlock->hash !== $currentBlock->calculateHash()) {
                return false;
            }

            if ($currentBlock->previousHash !== $previousBlock->hash) {
                return false;
            }
        }
        return true;
    }
}

// Create a new blockchain
$myBlockchain = new Blockchain();

// Add blocks to the blockchain
$block1 = new Block(1, "First Block");
$myBlockchain->addBlock($block1);

$block2 = new Block(2, "Second Block");
$myBlockchain->addBlock($block2);

// Validate the blockchain
if ($myBlockchain->isValid()) {
    echo "Blockchain is valid.\n";
} else {
    echo "Blockchain is not valid.\n";
}

?>
